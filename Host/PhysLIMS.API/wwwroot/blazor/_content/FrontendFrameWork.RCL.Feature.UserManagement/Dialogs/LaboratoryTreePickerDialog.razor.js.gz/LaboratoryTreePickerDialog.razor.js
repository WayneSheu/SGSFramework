// JavaScript for LaboratoryTreePickerDialog component
